# ResQNet — Backend Setup Guide

## Project structure

```
resqnet/
├── app.py                  ← Flask entry point
├── config.py               ← MySQL & secret key settings
├── requirements.txt
├── schema.sql              ← Run this in MySQL first
├── models/
│   └── db.py               ← All database table models
├── routes/
│   ├── auth.py             ← Register / Login / JWT
│   ├── incidents.py        ← Core incident reporting API
│   ├── resources.py        ← Emergency unit management
│   └── alerts.py           ← Public alert broadcast
└── ml/
    ├── classifier.py       ← AI severity classifier
    └── train_classifier.py ← Train & save the ML model
```

---

## Setup (step by step)

### 1. Create MySQL database
```bash
mysql -u root -p < schema.sql
```

### 2. Install Python dependencies
```bash
pip install -r requirements.txt
```

### 3. Set environment variables (or edit config.py)
```bash
export MYSQL_USER=root
export MYSQL_PASSWORD=your_password
export MYSQL_DB=resqnet
export SECRET_KEY=your-secret-key
export JWT_SECRET_KEY=your-jwt-secret
```

### 4. Train the AI model (optional but recommended)
```bash
python ml/train_classifier.py
```

### 5. Run the app
```bash
python app.py
```
Server starts at http://localhost:5000

---

## API Reference

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/auth/register | Register new user |
| POST | /api/auth/login | Login, get JWT token |
| GET  | /api/auth/me | Get current user |

### Incidents
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/incidents/report | Report new incident (AI classifies severity) |
| GET  | /api/incidents/ | List incidents (filter by status/severity/zone) |
| GET  | /api/incidents/<id> | Get single incident |
| PUT  | /api/incidents/<id>/status | Update incident status |
| GET  | /api/incidents/stats | Dashboard summary |
| GET  | /api/incidents/live | SSE real-time feed |

### Resources
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | /api/resources/ | List all units |
| POST | /api/resources/ | Add new unit |
| PUT  | /api/resources/<id>/status | Update unit status |
| GET  | /api/resources/availability | Summary by type |

### Alerts
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | /api/alerts/ | List alerts |
| POST | /api/alerts/send | Broadcast alert to a zone |

---

## Example: Report an incident

```bash
curl -X POST http://localhost:5000/api/incidents/report \
  -H "Content-Type: application/json" \
  -d '{
    "incident_type": "building_fire",
    "description": "Large fire spreading, multiple people trapped on 3rd floor",
    "location": "Sector 12, Block B",
    "zone": "A",
    "latitude": 28.6139,
    "longitude": 77.2090,
    "casualties": 5,
    "reported_by": 1
  }'
```

Response:
```json
{
  "id": 1,
  "severity": "critical",
  "severity_score": 0.876,
  "status": "dispatched",
  "assigned_units": 3,
  "ai_classification": {
    "severity": "critical",
    "severity_score": 0.876,
    "method": "ml",
    "recommended_units": 5
  },
  "message": "Incident reported. Emergency services notified."
}
```

## Real-time SocketIO events (for frontend)

Connect to: `http://localhost:5000` namespace `/live`

| Event | Triggered when |
|-------|----------------|
| `new_incident` | A new incident is reported |
| `incident_status_update` | Status changes (dispatched, resolved…) |
| `resources_dispatched` | Units auto-assigned to an incident |
| `public_alert` | An alert is broadcast to a zone |

Frontend example (JavaScript):
```javascript
const socket = io('http://localhost:5000', { path: '/socket.io' });
socket.of('/live').on('new_incident', (data) => {
  console.log('New incident:', data);
  // Update your dashboard UI here
});
```
