"""
Auth API
─────────
POST /api/auth/register
POST /api/auth/login
GET  /api/auth/me
"""

from flask import Blueprint, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import jwt, datetime
from functools import wraps
from flask import current_app

from models.db import db, User

auth_bp = Blueprint("auth", __name__)


# ── JWT decorator ─────────────────────────────────────────────────────────────
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
        if not token:
            return jsonify({"error": "Token missing"}), 401
        try:
            data    = jwt.decode(token, current_app.config["JWT_SECRET_KEY"], algorithms=["HS256"])
            user    = User.query.get(data["user_id"])
            if not user:
                raise ValueError("User not found")
        except Exception as e:
            return jsonify({"error": f"Invalid token: {e}"}), 401
        return f(user, *args, **kwargs)
    return decorated


# ─────────────────────────────────────────────────────────────────────────────
#  POST /api/auth/register
# ─────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    required = ["name", "email", "password"]
    missing  = [f for f in required if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing: {', '.join(missing)}"}), 422

    if User.query.filter_by(email=data["email"]).first():
        return jsonify({"error": "Email already registered"}), 409

    user = User(
        name     = data["name"],
        email    = data["email"],
        password = generate_password_hash(data["password"]),
        role     = data.get("role", "citizen"),
        phone    = data.get("phone"),
        zone     = data.get("zone"),
    )
    db.session.add(user)
    db.session.commit()

    return jsonify({"message": "Registered successfully", "user": user.to_dict()}), 201


# ─────────────────────────────────────────────────────────────────────────────
#  POST /api/auth/login
# ─────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json()
    user = User.query.filter_by(email=data.get("email")).first()

    if not user or not check_password_hash(user.password, data.get("password", "")):
        return jsonify({"error": "Invalid email or password"}), 401

    token = jwt.encode({
        "user_id": user.id,
        "role":    user.role,
        "exp":     datetime.datetime.utcnow() + datetime.timedelta(hours=12),
    }, current_app.config["JWT_SECRET_KEY"], algorithm="HS256")

    return jsonify({"token": token, "user": user.to_dict()}), 200


# ─────────────────────────────────────────────────────────────────────────────
#  GET /api/auth/me
# ─────────────────────────────────────────────────────────────────────────────
@auth_bp.route("/me", methods=["GET"])
@token_required
def me(current_user):
    return jsonify(current_user.to_dict()), 200
