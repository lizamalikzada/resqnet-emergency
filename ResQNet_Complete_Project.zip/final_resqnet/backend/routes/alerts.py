"""Alerts API — send public emergency alerts by zone"""

from flask import Blueprint, request, jsonify, current_app
from models.db import db, Alert, User

alerts_bp = Blueprint("alerts", __name__)

@alerts_bp.route("/", methods=["GET"])
def list_alerts():
    zone = request.args.get("zone")
    q    = Alert.query
    if zone:
        q = q.filter_by(zone=zone)
    alerts = q.order_by(Alert.sent_at.desc()).limit(50).all()
    return jsonify([a.to_dict() for a in alerts]), 200

@alerts_bp.route("/send", methods=["POST"])
def send_alert():
    """
    Body: { incident_id, zone, alert_type, message, channel, sent_by }
    Broadcasts to connected clients via SocketIO.
    Integrate Twilio here for real SMS delivery.
    """
    data = request.get_json()
    required = ["zone", "alert_type", "message"]
    missing  = [f for f in required if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing: {', '.join(missing)}"}), 422

    # Count recipients (citizens in that zone)
    recipients = User.query.filter_by(zone=data["zone"], role="citizen").count()

    alert = Alert(
        incident_id = data.get("incident_id"),
        zone        = data["zone"],
        alert_type  = data["alert_type"],
        message     = data["message"],
        channel     = data.get("channel", "app"),
        recipients  = recipients,
        sent_by     = data.get("sent_by"),
    )
    db.session.add(alert)
    db.session.commit()

    # Real-time push to frontend
    try:
        current_app.socketio.emit("public_alert", alert.to_dict(), namespace="/live")
    except Exception:
        pass

    # ── Twilio SMS integration (uncomment when you have credentials) ──────────
    # from twilio.rest import Client
    # client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
    # for user in User.query.filter_by(zone=data["zone"], role="citizen").all():
    #     if user.phone:
    #         client.messages.create(
    #             body=data["message"],
    #             from_=TWILIO_FROM_NUMBER,
    #             to=f"+91{user.phone}"
    #         )

    return jsonify({
        "message":    "Alert sent successfully",
        "alert":      alert.to_dict(),
        "recipients": recipients,
    }), 201
