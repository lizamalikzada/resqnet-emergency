"""
Incidents API
─────────────
POST   /api/incidents/report          — citizen/officer reports an incident
GET    /api/incidents/                 — list all incidents (filterable)
GET    /api/incidents/<id>             — get single incident
PUT    /api/incidents/<id>/status      — update status (dispatch, resolve …)
GET    /api/incidents/live             — server-sent events for real-time feed
GET    /api/incidents/stats            — dashboard summary stats
"""

from flask import Blueprint, request, jsonify, Response, current_app
from datetime import datetime
import json
import time

from models.db import db, Incident, Resource
from ml.classifier import classify_severity

incidents_bp = Blueprint("incidents", __name__)


# ── Helper: broadcast via SocketIO ────────────────────────────────────────────
def _broadcast(event: str, data: dict):
    """Push real-time update to all connected dashboard clients."""
    try:
        socketio = current_app.socketio
        socketio.emit(event, data, namespace="/live")
    except Exception:
        pass   # SocketIO not available (unit tests etc.)


# ─────────────────────────────────────────────────────────────────────────────
#  POST /api/incidents/report
# ─────────────────────────────────────────────────────────────────────────────
@incidents_bp.route("/report", methods=["POST"])
def report_incident():
    """
    Report a new emergency incident.
    Body (JSON):
      incident_type, description, location, zone,
      latitude, longitude, casualties, reported_by (user_id)
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON body required"}), 400

    required = ["incident_type", "location"]
    missing  = [f for f in required if not data.get(f)]
    if missing:
        return jsonify({"error": f"Missing fields: {', '.join(missing)}"}), 422

    # ── AI severity classification ─────────────────────────────────────────
    classification = classify_severity(
        incident_type = data.get("incident_type", ""),
        description   = data.get("description", ""),
        casualties    = int(data.get("casualties", 0)),
        zone          = data.get("zone", ""),
    )

    # ── Persist incident ───────────────────────────────────────────────────
    incident = Incident(
        incident_type  = data["incident_type"],
        description    = data.get("description", ""),
        location       = data["location"],
        zone           = data.get("zone", ""),
        latitude       = data.get("latitude"),
        longitude      = data.get("longitude"),
        casualties     = int(data.get("casualties", 0)),
        reported_by    = data.get("reported_by"),
        severity       = classification["severity"],
        severity_score = classification["severity_score"],
        status         = "reported",
    )
    db.session.add(incident)
    db.session.commit()

    response_payload = {
        **incident.to_dict(),
        "ai_classification": classification,
        "message": "Incident reported. Emergency services notified.",
    }

    # ── Real-time push to dashboard ────────────────────────────────────────
    _broadcast("new_incident", response_payload)

    # Auto-dispatch resources for critical/high incidents
    if classification["severity"] in ("critical", "high"):
        _auto_dispatch(incident, classification["recommended_units"])

    return jsonify(response_payload), 201


# ─────────────────────────────────────────────────────────────────────────────
#  GET /api/incidents/
# ─────────────────────────────────────────────────────────────────────────────
@incidents_bp.route("/", methods=["GET"])
def list_incidents():
    """
    Query params (all optional):
      status   — reported | dispatched | on_scene | resolved | cancelled
      severity — critical | high | medium | low
      zone     — A | B | C …
      limit    — default 50
    """
    q = Incident.query

    if status := request.args.get("status"):
        q = q.filter_by(status=status)
    if severity := request.args.get("severity"):
        q = q.filter_by(severity=severity)
    if zone := request.args.get("zone"):
        q = q.filter_by(zone=zone)

    limit     = min(int(request.args.get("limit", 50)), 200)
    incidents = q.order_by(Incident.reported_at.desc()).limit(limit).all()

    return jsonify([i.to_dict() for i in incidents]), 200


# ─────────────────────────────────────────────────────────────────────────────
#  GET /api/incidents/<id>
# ─────────────────────────────────────────────────────────────────────────────
@incidents_bp.route("/<int:incident_id>", methods=["GET"])
def get_incident(incident_id):
    incident = Incident.query.get_or_404(incident_id)
    return jsonify(incident.to_dict()), 200


# ─────────────────────────────────────────────────────────────────────────────
#  PUT /api/incidents/<id>/status
# ─────────────────────────────────────────────────────────────────────────────
@incidents_bp.route("/<int:incident_id>/status", methods=["PUT"])
def update_status(incident_id):
    """
    Update incident status.
    Body: { "status": "dispatched" | "on_scene" | "resolved" | "cancelled" }
    """
    incident = Incident.query.get_or_404(incident_id)
    data     = request.get_json()
    new_status = data.get("status")

    valid = {"dispatched", "on_scene", "resolved", "cancelled"}
    if new_status not in valid:
        return jsonify({"error": f"Status must be one of: {valid}"}), 422

    incident.status = new_status
    if new_status == "resolved":
        incident.resolved_at = datetime.utcnow()

    db.session.commit()

    update = {"incident_id": incident_id, "status": new_status}
    _broadcast("incident_status_update", update)

    return jsonify({"message": "Status updated", **update}), 200


# ─────────────────────────────────────────────────────────────────────────────
#  GET /api/incidents/stats
# ─────────────────────────────────────────────────────────────────────────────
@incidents_bp.route("/stats", methods=["GET"])
def stats():
    """Live summary for the command dashboard."""
    active   = Incident.query.filter(Incident.status.notin_(["resolved","cancelled"])).count()
    critical = Incident.query.filter_by(severity="critical").filter(
                   Incident.status.notin_(["resolved","cancelled"])).count()
    resolved_today = Incident.query.filter(
        Incident.status == "resolved",
        db.func.date(Incident.resolved_at) == datetime.utcnow().date()
    ).count()
    total = Incident.query.count()

    return jsonify({
        "active_incidents":  active,
        "critical_incidents": critical,
        "resolved_today":    resolved_today,
        "total_incidents":   total,
    }), 200


# ─────────────────────────────────────────────────────────────────────────────
#  GET /api/incidents/live   (Server-Sent Events fallback)
# ─────────────────────────────────────────────────────────────────────────────
@incidents_bp.route("/live", methods=["GET"])
def live_feed():
    """
    SSE stream: sends the latest 10 active incidents every 5 seconds.
    Use this if you prefer SSE over SocketIO in your frontend.
    """
    def stream():
        while True:
            incidents = (
                Incident.query
                .filter(Incident.status.notin_(["resolved","cancelled"]))
                .order_by(Incident.reported_at.desc())
                .limit(10).all()
            )
            payload = json.dumps([i.to_dict() for i in incidents])
            yield f"data: {payload}\n\n"
            time.sleep(5)

    return Response(stream(), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


# ─────────────────────────────────────────────────────────────────────────────
#  Internal: auto-dispatch available resources
# ─────────────────────────────────────────────────────────────────────────────
def _auto_dispatch(incident: Incident, units_needed: int):
    """
    Automatically assign available resources to a critical/high incident.
    Prefers resources in the same zone, then any available.
    """
    available = (
        Resource.query
        .filter_by(status="available")
        .filter(Resource.zone == incident.zone)
        .limit(units_needed).all()
    )
    if len(available) < units_needed:
        extra = (
            Resource.query
            .filter_by(status="available")
            .filter(Resource.zone != incident.zone)
            .limit(units_needed - len(available)).all()
        )
        available.extend(extra)

    dispatched = []
    for resource in available:
        resource.status      = "deployed"
        resource.incident_id = incident.id
        dispatched.append(resource.unit_id)

    incident.assigned_units = len(dispatched)
    incident.status         = "dispatched" if dispatched else "reported"
    db.session.commit()

    if dispatched:
        _broadcast("resources_dispatched", {
            "incident_id": incident.id,
            "units":       dispatched,
            "severity":    incident.severity,
        })
