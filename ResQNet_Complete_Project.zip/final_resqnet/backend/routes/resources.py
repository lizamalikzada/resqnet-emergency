"""Resources API — manage emergency units"""

from flask import Blueprint, request, jsonify
from models.db import db, Resource

resources_bp = Blueprint("resources", __name__)

@resources_bp.route("/", methods=["GET"])
def list_resources():
    status    = request.args.get("status")
    zone      = request.args.get("zone")
    unit_type = request.args.get("unit_type")
    q = Resource.query
    if status:    q = q.filter_by(status=status)
    if zone:      q = q.filter_by(zone=zone)
    if unit_type: q = q.filter_by(unit_type=unit_type)
    return jsonify([r.to_dict() for r in q.all()]), 200

@resources_bp.route("/", methods=["POST"])
def add_resource():
    data = request.get_json()
    r = Resource(
        unit_id   = data["unit_id"],
        unit_type = data["unit_type"],
        zone      = data.get("zone"),
        operator  = data.get("operator"),
        contact   = data.get("contact"),
    )
    db.session.add(r)
    db.session.commit()
    return jsonify(r.to_dict()), 201

@resources_bp.route("/<int:resource_id>/status", methods=["PUT"])
def update_resource_status(resource_id):
    r    = Resource.query.get_or_404(resource_id)
    data = request.get_json()
    r.status      = data.get("status", r.status)
    r.incident_id = data.get("incident_id", r.incident_id)
    db.session.commit()
    return jsonify(r.to_dict()), 200

@resources_bp.route("/availability", methods=["GET"])
def availability_summary():
    types = ["fire_engine","ambulance","police","helicopter","rescue_team"]
    result = {}
    for t in types:
        total     = Resource.query.filter_by(unit_type=t).count()
        available = Resource.query.filter_by(unit_type=t, status="available").count()
        result[t] = {"total": total, "available": available, "deployed": total - available}
    return jsonify(result), 200
