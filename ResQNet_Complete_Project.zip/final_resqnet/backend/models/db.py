from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

# ─────────────────────────────────────────────────────────────
#  Users  (admin / field officers / citizens)
# ─────────────────────────────────────────────────────────────
class User(db.Model):
    __tablename__ = "users"
    id         = db.Column(db.Integer, primary_key=True)
    name       = db.Column(db.String(100), nullable=False)
    email      = db.Column(db.String(120), unique=True, nullable=False)
    password   = db.Column(db.String(255), nullable=False)   # bcrypt hash
    role       = db.Column(db.Enum("admin","officer","citizen"), default="citizen")
    phone      = db.Column(db.String(15))
    zone       = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id, "name": self.name,
            "email": self.email, "role": self.role,
            "phone": self.phone, "zone": self.zone,
        }

# ─────────────────────────────────────────────────────────────
#  Incidents
# ─────────────────────────────────────────────────────────────
class Incident(db.Model):
    __tablename__ = "incidents"
    id              = db.Column(db.Integer, primary_key=True)
    incident_type   = db.Column(db.String(50), nullable=False)   # fire, flood, accident …
    description     = db.Column(db.Text)
    location        = db.Column(db.String(200), nullable=False)
    zone            = db.Column(db.String(10))
    latitude        = db.Column(db.Float)
    longitude       = db.Column(db.Float)

    # AI-assigned severity: critical / high / medium / low
    severity        = db.Column(db.Enum("critical","high","medium","low"), default="medium")
    severity_score  = db.Column(db.Float, default=0.0)   # 0-1 confidence from ML model

    status          = db.Column(
        db.Enum("reported","dispatched","on_scene","resolved","cancelled"),
        default="reported"
    )
    reported_by     = db.Column(db.Integer, db.ForeignKey("users.id"))
    assigned_units  = db.Column(db.Integer, default=0)
    casualties      = db.Column(db.Integer, default=0)
    reported_at     = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at     = db.Column(db.DateTime)

    def to_dict(self):
        return {
            "id": self.id,
            "incident_type": self.incident_type,
            "description": self.description,
            "location": self.location,
            "zone": self.zone,
            "latitude": self.latitude,
            "longitude": self.longitude,
            "severity": self.severity,
            "severity_score": round(self.severity_score, 3),
            "status": self.status,
            "reported_by": self.reported_by,
            "assigned_units": self.assigned_units,
            "casualties": self.casualties,
            "reported_at": self.reported_at.isoformat(),
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
        }

# ─────────────────────────────────────────────────────────────
#  Emergency resources  (vehicles, personnel)
# ─────────────────────────────────────────────────────────────
class Resource(db.Model):
    __tablename__ = "resources"
    id           = db.Column(db.Integer, primary_key=True)
    unit_id      = db.Column(db.String(20), unique=True, nullable=False)  # e.g. "FIRE-01"
    unit_type    = db.Column(db.Enum("fire_engine","ambulance","police","helicopter","rescue_team"))
    zone         = db.Column(db.String(10))
    status       = db.Column(db.Enum("available","deployed","maintenance","offline"), default="available")
    incident_id  = db.Column(db.Integer, db.ForeignKey("incidents.id"), nullable=True)
    operator     = db.Column(db.String(100))
    contact      = db.Column(db.String(15))
    last_updated = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id, "unit_id": self.unit_id,
            "unit_type": self.unit_type, "zone": self.zone,
            "status": self.status, "incident_id": self.incident_id,
            "operator": self.operator, "contact": self.contact,
        }

# ─────────────────────────────────────────────────────────────
#  Public alerts
# ─────────────────────────────────────────────────────────────
class Alert(db.Model):
    __tablename__ = "alerts"
    id          = db.Column(db.Integer, primary_key=True)
    incident_id = db.Column(db.Integer, db.ForeignKey("incidents.id"))
    zone        = db.Column(db.String(10))
    alert_type  = db.Column(db.String(50))    # evacuation, shelter, road_closure, all_clear
    message     = db.Column(db.Text, nullable=False)
    channel     = db.Column(db.String(20))    # sms, app, both
    recipients  = db.Column(db.Integer, default=0)
    sent_by     = db.Column(db.Integer, db.ForeignKey("users.id"))
    sent_at     = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id, "incident_id": self.incident_id,
            "zone": self.zone, "alert_type": self.alert_type,
            "message": self.message, "channel": self.channel,
            "recipients": self.recipients,
            "sent_at": self.sent_at.isoformat(),
        }
