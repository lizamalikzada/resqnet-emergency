-- ResQNet MySQL Schema
-- Run this in MySQL before starting the Flask app:
--   mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS resqnet;
USE resqnet;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    name       VARCHAR(100)  NOT NULL,
    email      VARCHAR(120)  NOT NULL UNIQUE,
    password   VARCHAR(255)  NOT NULL,
    role       ENUM('admin','officer','citizen') DEFAULT 'citizen',
    phone      VARCHAR(15),
    zone       VARCHAR(10),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Incidents table
CREATE TABLE IF NOT EXISTS incidents (
    id             INT AUTO_INCREMENT PRIMARY KEY,
    incident_type  VARCHAR(50)  NOT NULL,
    description    TEXT,
    location       VARCHAR(200) NOT NULL,
    zone           VARCHAR(10),
    latitude       FLOAT,
    longitude      FLOAT,
    severity       ENUM('critical','high','medium','low') DEFAULT 'medium',
    severity_score FLOAT DEFAULT 0.0,
    status         ENUM('reported','dispatched','on_scene','resolved','cancelled') DEFAULT 'reported',
    reported_by    INT,
    assigned_units INT DEFAULT 0,
    casualties     INT DEFAULT 0,
    reported_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
    resolved_at    DATETIME,
    FOREIGN KEY (reported_by) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_status   (status),
    INDEX idx_severity (severity),
    INDEX idx_zone     (zone)
);

-- Resources table
CREATE TABLE IF NOT EXISTS resources (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    unit_id      VARCHAR(20) NOT NULL UNIQUE,
    unit_type    ENUM('fire_engine','ambulance','police','helicopter','rescue_team'),
    zone         VARCHAR(10),
    status       ENUM('available','deployed','maintenance','offline') DEFAULT 'available',
    incident_id  INT,
    operator     VARCHAR(100),
    contact      VARCHAR(15),
    last_updated DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE SET NULL
);

-- Alerts table
CREATE TABLE IF NOT EXISTS alerts (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    incident_id INT,
    zone        VARCHAR(10),
    alert_type  VARCHAR(50),
    message     TEXT NOT NULL,
    channel     VARCHAR(20) DEFAULT 'app',
    recipients  INT DEFAULT 0,
    sent_by     INT,
    sent_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES incidents(id) ON DELETE SET NULL,
    FOREIGN KEY (sent_by)     REFERENCES users(id)     ON DELETE SET NULL
);

-- Seed: sample resources
INSERT INTO resources (unit_id, unit_type, zone, status) VALUES
('FIRE-01','fire_engine','A','available'),
('FIRE-02','fire_engine','B','available'),
('FIRE-03','fire_engine','A','available'),
('AMB-01','ambulance','A','available'),
('AMB-02','ambulance','C','available'),
('AMB-03','ambulance','B','available'),
('POL-01','police','A','available'),
('POL-02','police','B','available'),
('POL-03','police','D','available'),
('HELI-01','helicopter','HQ','available');

-- Seed: admin user (password: admin123)
INSERT INTO users (name, email, password, role) VALUES
('Admin User','admin@resqnet.com',
 '$2b$12$EixZaYVK1fsbw1ZfbX3OXePaWxn96p36WQoeG6Lruj3vjPGga31lW',
 'admin');
