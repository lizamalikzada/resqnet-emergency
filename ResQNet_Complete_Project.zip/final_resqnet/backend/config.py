import os

class Config:
    # ── MySQL connection ──────────────────────────────────────────────────────
    # Update these values to match your local MySQL setup
    MYSQL_HOST     = os.getenv("MYSQL_HOST",     "localhost")
    MYSQL_PORT     = int(os.getenv("MYSQL_PORT", 3306))
    MYSQL_USER     = os.getenv("MYSQL_USER",     "root")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "your_password")
    MYSQL_DB       = os.getenv("MYSQL_DB",       "resqnet")

    SQLALCHEMY_DATABASE_URI = (
        f"mysql+pymysql://{MYSQL_USER}:{MYSQL_PASSWORD}"
        f"@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DB}"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # ── Security ──────────────────────────────────────────────────────────────
    SECRET_KEY     = os.getenv("SECRET_KEY", "change-this-in-production")
    JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "jwt-secret-change-this")

    # ── Real-time ─────────────────────────────────────────────────────────────
    # How often (seconds) the live dashboard auto-refreshes via SocketIO
    SOCKETIO_PING_INTERVAL = 25
