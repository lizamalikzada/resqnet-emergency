"""
Train the ResQNet severity classifier and save it to ml/severity_model.pkl
Run once:  python ml/train_classifier.py
"""

import pickle
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

# ── Synthetic training data ────────────────────────────────────────────────────
# Features: [type_score, keyword_score, casualties_boost, casualties_count]
# Label:     1 = high/critical, 0 = medium/low

np.random.seed(42)

X = np.array([
    # critical/high examples
    [0.95, 0.90, 0.15, 12], [0.90, 0.90, 0.08, 5], [0.85, 0.70, 0.15, 10],
    [0.88, 0.90, 0.15, 15], [0.80, 0.70, 0.08, 4], [0.75, 0.70, 0.04, 2],
    [0.70, 0.70, 0.08, 3],  [0.85, 0.90, 0.15, 8], [0.90, 0.70, 0.08, 6],
    [0.80, 0.90, 0.15, 20], [0.95, 0.70, 0.15, 9], [0.75, 0.90, 0.08, 4],
    [0.88, 0.70, 0.15, 11], [0.85, 0.90, 0.08, 7], [0.70, 0.90, 0.04, 2],
    # medium/low examples
    [0.50, 0.50, 0.00, 0],  [0.60, 0.50, 0.04, 1], [0.50, 0.40, 0.00, 0],
    [0.40, 0.25, 0.00, 0],  [0.55, 0.50, 0.04, 1], [0.60, 0.40, 0.00, 0],
    [0.50, 0.25, 0.00, 0],  [0.45, 0.50, 0.00, 0], [0.50, 0.40, 0.04, 1],
    [0.40, 0.40, 0.00, 0],  [0.55, 0.25, 0.00, 0], [0.60, 0.50, 0.00, 0],
    [0.45, 0.40, 0.04, 1],  [0.50, 0.50, 0.00, 0], [0.40, 0.25, 0.00, 0],
])

y = np.array([1]*15 + [0]*15)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

print("=== Model Evaluation ===")
print(classification_report(y_test, model.predict(X_test),
      target_names=["medium/low", "high/critical"]))

model_path = "ml/severity_model.pkl"
with open(model_path, "wb") as f:
    pickle.dump(model, f)

print(f"✅ Model saved to {model_path}")
print("   Now restart app.py — the AI classifier will use this model automatically.")
