"""
Severity Classifier for ResQNet
--------------------------------
Two-stage approach:
  1. Rule-based engine  — fast, deterministic, covers keyword signals
  2. ML model (sklearn) — trained on historical incident data (optional,
     falls back gracefully if model file is missing)

Severity levels: critical | high | medium | low
"""

import re
import os
import pickle
import numpy as np

# ── Keyword signal tables ──────────────────────────────────────────────────────

CRITICAL_KEYWORDS = [
    "explosion", "blast", "building collapse", "mass casualty",
    "chemical leak", "gas explosion", "earthquake", "dam breach",
    "multiple casualties", "trapped", "fire spreading",
]

HIGH_KEYWORDS = [
    "fire", "flood", "major accident", "serious injury",
    "unconscious", "heart attack", "stroke", "drowning",
    "structural damage", "gas leak", "large crowd",
]

MEDIUM_KEYWORDS = [
    "accident", "injury", "road block", "power outage",
    "tree fallen", "minor fire", "medical", "chest pain",
]

LOW_KEYWORDS = [
    "noise complaint", "minor incident", "suspicious activity",
    "pothole", "stray animal", "vandalism",
]

# Incident type base scores (0-1)
TYPE_BASE_SCORE = {
    "explosion":       0.95,
    "building_fire":   0.85,
    "earthquake":      0.90,
    "flood":           0.80,
    "chemical_spill":  0.88,
    "road_accident":   0.65,
    "medical":         0.60,
    "gas_leak":        0.75,
    "rescue":          0.70,
    "other":           0.50,
}

# ── Helpers ───────────────────────────────────────────────────────────────────

def _keyword_score(text: str) -> float:
    """Return a 0-1 score based on keyword matches."""
    text = text.lower()
    if any(k in text for k in CRITICAL_KEYWORDS):
        return 0.90
    if any(k in text for k in HIGH_KEYWORDS):
        return 0.70
    if any(k in text for k in MEDIUM_KEYWORDS):
        return 0.50
    if any(k in text for k in LOW_KEYWORDS):
        return 0.25
    return 0.40   # default: medium-ish


def _score_to_label(score: float) -> str:
    if score >= 0.80:
        return "critical"
    if score >= 0.60:
        return "high"
    if score >= 0.35:
        return "medium"
    return "low"


def _casualties_boost(casualties: int) -> float:
    """Extra score boost based on reported casualties."""
    if casualties >= 10:
        return 0.15
    if casualties >= 3:
        return 0.08
    if casualties >= 1:
        return 0.04
    return 0.0


# ── ML model loader (optional) ────────────────────────────────────────────────

_ML_MODEL = None
_MODEL_PATH = os.path.join(os.path.dirname(__file__), "severity_model.pkl")

def _load_ml_model():
    global _ML_MODEL
    if _ML_MODEL is None and os.path.exists(_MODEL_PATH):
        with open(_MODEL_PATH, "rb") as f:
            _ML_MODEL = pickle.load(f)
    return _ML_MODEL


def _ml_predict(incident_type: str, description: str, casualties: int) -> float | None:
    """
    Use trained sklearn model if available.
    Returns a 0-1 probability for 'high or critical', or None if no model.

    To train and save the model, run: python ml/train_classifier.py
    """
    model = _load_ml_model()
    if model is None:
        return None
    try:
        type_score = TYPE_BASE_SCORE.get(incident_type.lower(), 0.5)
        kw_score   = _keyword_score(description)
        cas_boost  = _casualties_boost(casualties)
        features   = np.array([[type_score, kw_score, cas_boost, casualties]])
        prob       = model.predict_proba(features)[0][1]   # P(high/critical)
        return float(prob)
    except Exception:
        return None


# ── Public API ────────────────────────────────────────────────────────────────

def classify_severity(
    incident_type: str,
    description: str,
    casualties: int = 0,
    zone: str = "",
) -> dict:
    """
    Classify incident severity.

    Returns:
        {
          "severity":       "critical" | "high" | "medium" | "low",
          "severity_score": float (0-1),
          "method":         "ml" | "rule_based",
          "recommended_units": int,
        }
    """
    description = description or ""
    incident_type = incident_type or "other"

    # Stage 1 — rule-based score
    type_score = TYPE_BASE_SCORE.get(incident_type.lower().replace(" ", "_"), 0.50)
    kw_score   = _keyword_score(description)
    cas_boost  = _casualties_boost(casualties)
    rule_score = min(1.0, (type_score * 0.5) + (kw_score * 0.4) + cas_boost)

    # Stage 2 — ML override if model is available
    ml_score = _ml_predict(incident_type, description, casualties)
    if ml_score is not None:
        # Weighted blend: 60% ML, 40% rule-based
        final_score = (ml_score * 0.60) + (rule_score * 0.40)
        method = "ml"
    else:
        final_score = rule_score
        method = "rule_based"

    severity = _score_to_label(final_score)

    # Recommended units to dispatch
    units_map = {"critical": 5, "high": 3, "medium": 2, "low": 1}

    return {
        "severity":          severity,
        "severity_score":    round(final_score, 4),
        "method":            method,
        "recommended_units": units_map[severity],
    }
