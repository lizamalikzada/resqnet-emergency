from flask import Flask
from flask_socketio import SocketIO
from flask_cors import CORS
from config import Config
from models.db import db
from routes.incidents import incidents_bp
from routes.resources import resources_bp
from routes.alerts import alerts_bp
from routes.auth import auth_bp

app = Flask(__name__)
app.config.from_object(Config)

CORS(app)
db.init_app(app)
socketio = SocketIO(app, cors_allowed_origins="*")

app.register_blueprint(auth_bp,      url_prefix="/api/auth")
app.register_blueprint(incidents_bp, url_prefix="/api/incidents")
app.register_blueprint(resources_bp, url_prefix="/api/resources")
app.register_blueprint(alerts_bp,    url_prefix="/api/alerts")

# Make socketio available to blueprints
app.socketio = socketio

@app.route("/api/health")
def health():
    return {"status": "ResQNet backend running"}, 200

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
        print("✅ Database tables created.")
    socketio.run(app, debug=True, host="0.0.0.0", port=5000)
